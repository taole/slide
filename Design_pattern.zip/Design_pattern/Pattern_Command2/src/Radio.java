
public class Radio implements ElectronicDevice{

	private int volume = 0;
	
	@Override
	public void on() {
		System.out.println("Radio is On!");
	}

	@Override
	public void off() {
		System.out.println("Radio is Off");
		
	}

	@Override
	public void volumeUp() {
		// TODO Auto-generated method stub
		this.volume++;
		System.out.println("Radio volume is at:" + this.volume);
	}

	@Override
	public void volumeDown() {
		// TODO Auto-generated method stub
		this.volume--;
		System.out.println("Radio volume is at:" + this.volume);		
	}
	
}
