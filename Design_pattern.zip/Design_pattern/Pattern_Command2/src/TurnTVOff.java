
public class TurnTVOff implements Command {

	ElectronicDevice theDevice;

	public TurnTVOff(ElectronicDevice theDevice) {
		this.theDevice = theDevice;
	}
	
	@Override
	public void execute() {
		this.theDevice.off();
	}

	@Override
	public void undo() {
		this.theDevice.on();
	}
	
	
}
