 
public class TurnTVUp implements Command{

	private ElectronicDevice theDevice;
	
	
	
	public TurnTVUp(ElectronicDevice theDevice) {
		this.theDevice = theDevice;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		this.theDevice.volumeUp();
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		this.theDevice.volumeDown();
	}
	
}
