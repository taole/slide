import java.util.List;


public class TurnItAllOff implements Command {
	
	List<ElectronicDevice> theDevice;
	
	public TurnItAllOff(List<ElectronicDevice> newDevices) {
		this.theDevice = newDevices;
	}
	
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		for (ElectronicDevice device : theDevice) {
			device.off();
		}
	}

	@Override
	public void undo() {
		// TODO Auto-generated method stub
		for (ElectronicDevice device : theDevice) {
			device.on();
		}
	}
	
}
