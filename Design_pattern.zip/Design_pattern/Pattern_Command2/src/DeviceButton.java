
public class DeviceButton {
	Command theCommand;

	public DeviceButton(Command theCommand) {
		this.theCommand = theCommand;
	}
	
	public void press() {
		this.theCommand.execute();
	}
	
	public void pressUndo() {
		this.theCommand.undo();
	}
}
